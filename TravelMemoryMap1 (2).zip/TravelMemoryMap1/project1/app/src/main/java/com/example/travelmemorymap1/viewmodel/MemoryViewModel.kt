package com.example.travelmemorymap1.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.travelmemorymap1.data.MemoryRepository
import com.example.travelmemorymap1.domain.Memory
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MemoryListState(
    val memories: List<Memory> = emptyList(),
    val query: String = ""
)

@HiltViewModel
class MemoryViewModel @Inject constructor(
    private val repository: MemoryRepository
) : ViewModel() {

    private val _state = MutableStateFlow(MemoryListState())
    val state: StateFlow<MemoryListState> = _state.asStateFlow()

    init {
        loadMemories()
    }

    private fun loadMemories() {
        viewModelScope.launch {
            repository.getAllMemories().collect { list ->
                _state.update { it.copy(memories = list) }
            }
        }
    }

    fun onQueryChange(query: String) {
        _state.update { it.copy(query = query) }
        viewModelScope.launch {
            if (query.isBlank()) {
                repository.getAllMemories().collect { list ->
                    _state.update { s -> s.copy(memories = list) }
                }
            } else {
                repository.searchMemories(query).collect { list ->
                    _state.update { s -> s.copy(memories = list) }
                }
            }
        }
    }
}

