package com.example.travelmemorymap1.sync

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.example.travelmemorymap1.data.MemoryRepository
import com.example.travelmemorymap1.network.MemoryRemoteRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MemorySyncService : Service() {

    @Inject lateinit var repository: MemoryRepository
    @Inject lateinit var remoteRepository: MemoryRemoteRepository

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        scope.launch {
            val unsynced = repository.getUnsyncedMemories()
            unsynced.forEach { memory ->
                try {
                    remoteRepository.createMemory(memory)
                    repository.updateMemory(memory.copy(isSynced = true))
                } catch (_: Exception) {
                    // Keep sync best-effort; failed memories remain unsynced for retry.
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

