package com.example.travelmemorymap1.data

import com.example.travelmemorymap1.domain.Memory

/**
 * API/cloud transfer model.
 * Default values keep it compatible with Firestore object deserialization.
 */
    data class MemoryDto(
        val id: String = "",
        val title: String = "",
        val description: String = "",
        val imageUri: String = "",
        val latitude: Double = 0.0,
        val longitude: Double = 0.0,
        val timestamp: Long = 0L,
        val isSynced: Boolean = false
    )

fun Memory.toDto() = MemoryDto(
    id = id,
    title = title,
    description = description,
    imageUri = imageUri,
    latitude = latitude,
    longitude = longitude,
    timestamp = timestamp,
    isSynced = isSynced
)

fun MemoryDto.toDomain() = Memory(
    id = id,
    title = title,
    description = description,
    imageUri = imageUri,
    latitude = latitude,
    longitude = longitude,
    timestamp = timestamp,
    isSynced = isSynced
)
