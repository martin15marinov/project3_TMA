package com.example.travelmemorymap1.network

import com.example.travelmemorymap1.data.toDomain
import com.example.travelmemorymap1.data.toDto
import com.example.travelmemorymap1.domain.Memory
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MemoryRemoteRepository @Inject constructor(
    private val apiService: MemoryApiService
) {
    suspend fun getMemories(): List<Memory> =
        apiService.getMemories().map { it.toDomain() }

    suspend fun getMemoryById(id: String): Memory =
        apiService.getMemoryById(id).toDomain()

    suspend fun createMemory(memory: Memory): Memory =
        apiService.createMemory(memory.toDto()).toDomain()

    suspend fun updateMemory(memory: Memory): Memory =
        apiService.updateMemory(memory.id, memory.toDto()).toDomain()

    suspend fun deleteMemory(id: String) {
        apiService.deleteMemory(id)
    }
}
