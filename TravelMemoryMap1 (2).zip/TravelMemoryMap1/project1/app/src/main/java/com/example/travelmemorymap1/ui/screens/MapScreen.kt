package com.example.travelmemorymap1.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.rememberCameraPositionState

@Composable
fun MapScreen(
    onAddMemory: () -> Unit,
    onOpenMemory: (String) -> Unit
) {
    // TODO: Hook ViewModel, permissions, and real memory markers.
    val cameraPositionState = rememberCameraPositionState()

    Box(modifier = Modifier.fillMaxSize()) {
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState
        ) {
            // Placeholder marker
            Marker(
                position = com.google.android.gms.maps.model.LatLng(0.0, 0.0),
                title = "No memories yet",
                snippet = "Add your first travel memory"
            )
        }

        FloatingActionButton(
            onClick = onAddMemory,
            modifier = Modifier
                .align(Alignment.BottomEnd)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add memory")
        }
    }
}

