package com.example.travelmemorymap1.domain

data class Memory(
    val id: String,
    val title: String,
    val description: String,
    val imageUri: String,
    val latitude: Double,
    val longitude: Double,
    val timestamp: Long,
    val isSynced: Boolean
)
