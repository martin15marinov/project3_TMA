package com.example.travelmemorymap1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.travelmemorymap1.ui.screens.AddEditMemoryScreen
import com.example.travelmemorymap1.ui.screens.DetailScreen
import com.example.travelmemorymap1.ui.screens.MapScreen
import com.example.travelmemorymap1.ui.screens.MemoryListScreen
import com.example.travelmemorymap1.ui.theme.TravelMemoryMap1Theme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TravelMemoryMap1Theme {
                val navController = rememberNavController()
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "map",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("map") {
                            MapScreen(
                                onAddMemory = { navController.navigate("add") },
                                onOpenMemory = { id -> navController.navigate("detail/$id") }
                            )
                        }
                        composable("list") {
                            MemoryListScreen(
                                onBack = { navController.popBackStack() },
                                onOpenMemory = { id -> navController.navigate("detail/$id") }
                            )
                        }
                        composable("add") {
                            AddEditMemoryScreen(
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("detail/{memoryId}") {
                            DetailScreen(
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}