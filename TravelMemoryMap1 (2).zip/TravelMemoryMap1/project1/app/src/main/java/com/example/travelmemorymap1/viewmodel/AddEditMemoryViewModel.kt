package com.example.travelmemorymap1.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.travelmemorymap1.data.MemoryRepository
import com.example.travelmemorymap1.domain.Memory
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AddEditMemoryState(
    val title: String = "",
    val description: String = "",
    val canSave: Boolean = false
)

@HiltViewModel
class AddEditMemoryViewModel @Inject constructor(
    private val repository: MemoryRepository
) : ViewModel() {

    private val _state = MutableStateFlow(AddEditMemoryState())
    val state: StateFlow<AddEditMemoryState> = _state.asStateFlow()

    fun onTitleChange(title: String) {
        _state.update { it.copy(title = title, canSave = title.isNotBlank()) }
    }

    fun onDescriptionChange(description: String) {
        _state.update { it.copy(description = description, canSave = it.title.isNotBlank()) }
    }

    fun saveMemory() {
        val current = _state.value
        if (!current.canSave) return

        viewModelScope.launch {
            val memory = Memory(
                id = "",
                title = current.title,
                description = current.description,
                imageUri = "",
                latitude = 0.0,
                longitude = 0.0,
                timestamp = System.currentTimeMillis(),
                isSynced = false
            )
            repository.addMemory(memory)
        }
    }
}

