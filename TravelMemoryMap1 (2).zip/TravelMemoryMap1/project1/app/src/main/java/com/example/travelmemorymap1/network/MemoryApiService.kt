package com.example.travelmemorymap1.network

import com.example.travelmemorymap1.data.MemoryDto
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface MemoryApiService {

    @GET("memories")
    suspend fun getMemories(): List<MemoryDto>

    @GET("memories/{id}")
    suspend fun getMemoryById(@Path("id") id: String): MemoryDto

    @POST("memories")
    suspend fun createMemory(@Body memory: MemoryDto): MemoryDto

    @PUT("memories/{id}")
    suspend fun updateMemory(
        @Path("id") id: String,
        @Body memory: MemoryDto
    ): MemoryDto

    @DELETE("memories/{id}")
    suspend fun deleteMemory(@Path("id") id: String)
}
