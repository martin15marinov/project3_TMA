package com.example.travelmemorymap1.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.travelmemorymap1.data.MemoryRepository
import com.example.travelmemorymap1.domain.Memory
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DetailState(
    val memory: Memory? = null
)

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val repository: MemoryRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _state = MutableStateFlow(DetailState())
    val state: StateFlow<DetailState> = _state.asStateFlow()

    private val memoryId: String? = savedStateHandle["memoryId"]

    init {
        memoryId?.let { id ->
            viewModelScope.launch {
                repository.getMemoryById(id).collect { memory ->
                    _state.value = DetailState(memory)
                }
            }
        }
    }
}

