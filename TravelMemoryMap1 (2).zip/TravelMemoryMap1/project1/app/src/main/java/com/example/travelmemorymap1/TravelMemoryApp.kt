package com.example.travelmemorymap1

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TravelMemoryApp : Application()

