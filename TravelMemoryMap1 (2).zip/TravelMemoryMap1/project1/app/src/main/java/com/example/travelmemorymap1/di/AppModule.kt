package com.example.travelmemorymap1.di

import android.app.Application
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Room
import com.example.travelmemorymap1.data.AppDatabase
import com.example.travelmemorymap1.data.MemoryDao
import com.example.travelmemorymap1.data.MemoryRepository
import com.example.travelmemorymap1.network.MemoryApiService
import com.example.travelmemorymap1.network.MemoryRemoteRepository
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

private const val PREFS_NAME = "travel_prefs"
private const val API_BASE_URL = "https://example.com/api/"

val Application.dataStore by preferencesDataStore(PREFS_NAME)

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(app: Application): AppDatabase =
        Room.databaseBuilder(app, AppDatabase::class.java, "travel_memories.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideMemoryDao(db: AppDatabase): MemoryDao = db.memoryDao()

    @Provides
    @Singleton
    fun provideMemoryRepository(dao: MemoryDao): MemoryRepository = MemoryRepository(dao)

    @Provides
    @Singleton
    fun provideFusedLocationProvider(app: Application) =
        LocationServices.getFusedLocationProviderClient(app)

    @Provides
    @Singleton
    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

    @Provides
    @Singleton
    fun provideFirestore(): FirebaseFirestore = FirebaseFirestore.getInstance()

    @Provides
    @Singleton
    fun provideFirebaseStorage(): FirebaseStorage = FirebaseStorage.getInstance()

    @Provides
    @Singleton
    fun provideRetrofit(): Retrofit =
        Retrofit.Builder()
            .baseUrl(API_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    @Provides
    @Singleton
    fun provideMemoryApiService(retrofit: Retrofit): MemoryApiService =
        retrofit.create(MemoryApiService::class.java)

    @Provides
    @Singleton
    fun provideMemoryRemoteRepository(apiService: MemoryApiService): MemoryRemoteRepository =
        MemoryRemoteRepository(apiService)
}

