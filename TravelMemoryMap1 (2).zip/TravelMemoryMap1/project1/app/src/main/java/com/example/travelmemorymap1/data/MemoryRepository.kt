package com.example.travelmemorymap1.data

import com.example.travelmemorymap1.domain.Memory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MemoryRepository @Inject constructor(
    private val dao: MemoryDao
) {

    fun getAllMemories(): Flow<List<Memory>> =
        dao.getAllMemories().map { list -> list.map { it.toDomain() } }

    fun getMemoryById(id: String): Flow<Memory?> =
        dao.getMemoryById(id).map { it?.toDomain() }

    fun searchMemories(query: String): Flow<List<Memory>> =
        dao.searchMemories(query).map { list -> list.map { it.toDomain() } }

    suspend fun addMemory(memory: Memory) {
        dao.insertMemory(memory.toEntity())
    }

    suspend fun updateMemory(memory: Memory) {
        dao.updateMemory(memory.toEntity())
    }

    suspend fun deleteMemory(id: String) {
        dao.deleteMemory(id)
    }

    suspend fun getUnsyncedMemories(): List<Memory> {
        return dao.getAllMemories().first().filter { !it.isSynced }.map { it.toDomain() }
    }
}

fun MemoryEntity.toDomain() = Memory(
    id = id,
    title = title,
    description = description,
    imageUri = imageUri,
    latitude = latitude,
    longitude = longitude,
    timestamp = timestamp,
    isSynced = isSynced
)

fun Memory.toEntity() = MemoryEntity(
    id = id,
    title = title,
    description = description,
    imageUri = imageUri,
    latitude = latitude,
    longitude = longitude,
    timestamp = timestamp,
    isSynced = isSynced
)

