package com.example.travelmemorymap1.data

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import junit.framework.TestCase.assertTrue
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Before
import org.junit.Test

class MemoryRepositoryTest {

    private lateinit var db: AppDatabase
    private lateinit var dao: MemoryDao
    private lateinit var repository: MemoryRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = db.memoryDao()
        repository = MemoryRepository(dao)
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun insertAndReadMemory() = runBlocking {
        val memory = Memory(
            id = "1",
            title = "Test",
            description = "Desc",
            imageUri = "",
            latitude = 0.0,
            longitude = 0.0,
            timestamp = 0L,
            isSynced = false
        )
        repository.addMemory(memory)

        val list = repository.getAllMemories().first()
        assertTrue(list.any { it.id == "1" })
    }
}

