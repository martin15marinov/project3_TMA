package com.example.travelmemorymap1.viewmodel

import com.example.travelmemorymap1.data.MemoryRepository
import com.example.travelmemorymap1.domain.Memory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.test.runTest
import org.junit.Test

private class FakeRepository : MemoryRepository(
    dao = object : com.example.travelmemorymap1.data.MemoryDao {
        override fun getAllMemories(): Flow<List<com.example.travelmemorymap1.data.MemoryEntity>> = emptyFlow()
        override fun getMemoryById(id: String): Flow<com.example.travelmemorymap1.data.MemoryEntity?> = emptyFlow()
        override suspend fun insertMemory(memory: com.example.travelmemorymap1.data.MemoryEntity) {}
        override suspend fun updateMemory(memory: com.example.travelmemorymap1.data.MemoryEntity) {}
        override suspend fun deleteMemory(id: String) {}
        override fun searchMemories(query: String): Flow<List<com.example.travelmemorymap1.data.MemoryEntity>> = emptyFlow()
    }
) {
    val saved = mutableListOf<Memory>()

    override suspend fun addMemory(memory: Memory) {
        saved.add(memory)
    }
}

class AddEditMemoryViewModelTest {

    @Test
    fun saveEnqueuesMemory() = runTest {
        val repo = FakeRepository()
        val vm = AddEditMemoryViewModel(repo)

        vm.onTitleChange("Trip")
        vm.onDescriptionChange("Fun")
        vm.saveMemory()

        assert(repo.state.value.canSave)
    }
}

